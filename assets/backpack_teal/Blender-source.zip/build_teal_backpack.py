import bpy,math,os,json
from mathutils import Vector
from pathlib import Path
out=Path(r'C:/Users/jkern/Documents/Codex/2026-10-16/go-x20/outputs/models/teal-backpack')
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,color,rough=.85,metal=0,tex=None):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 if tex:
  im=bpy.data.images.load(str(out/(tex+'.png')));im.pack();n=m.node_tree.nodes.new('ShaderNodeTexImage');n.image=im;m.node_tree.links.new(n.outputs['Color'],p.inputs['Base Color'])
 return m
teal=mat('Teal woven canvas',(.035,.30,.34),tex='canvas');tan=mat('Worn brown leather base',(.40,.22,.12),tex='leather');black=mat('Padded charcoal back',(.04,.045,.04),tex='padding');web=mat('Black nylon webbing',(.014,.018,.017));zipper=mat('Dark zipper tape',(.012,.025,.025));silver=mat('Aged nickel zipper pulls',(.43,.44,.39),.34,.8);thread=mat('Teal stitching',(.10,.36,.39));cream=mat('Warm cream embroidery',(.77,.72,.59));red=mat('Red label lettering',(.65,.10,.12));label=mat('Navy woven label',(.025,.075,.11));meshmat=mat('Black pocket mesh',(.018,.028,.027))
parts=[]
def finish(o,name,m):
 o.name=name;o.data.materials.append(m);parts.append(o);return o
def box(name,loc,size,m,bevel=.007):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  mod=o.modifiers.new('Soft fabric edges','BEVEL');mod.width=bevel;mod.segments=3;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
  o.modifiers.new('Weighted fabric normals','WEIGHTED_NORMAL')
 return finish(o,name,m)
def line(name,pts,r,m,cyclic=False):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=r;c.bevel_resolution=1;s=c.splines.new('POLY');s.points.add(len(pts)-1)
 for p,v in zip(s.points,pts):p.co=(*v,1)
 s.use_cyclic_u=cyclic;o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.data.materials.append(m);parts.append(o);return o
def ribbon(name,pts,width,m):
 vs=[]
 for x,y,z in pts:vs.extend([(x-width/2,y,z),(x+width/2,y,z)])
 fs=[(2*i,2*i+1,2*i+3,2*i+2) for i in range(len(pts)-1)];me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);finish(o,name,m)
 mod=o.modifiers.new('Fabric thickness','SOLIDIFY');mod.thickness=.005;bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.modifier_apply(modifier=mod.name);o.select_set(False);return o
# Soft arched silhouette: 34 cm wide, 44 cm tall, about 24 cm deep including pockets.
outline=[(-.145,.006),(.145,.006),(.167,.025),(.170,.28),(.164,.335),(.15,.375),(.123,.411),(.079,.434),(0,.444),(-.079,.434),(-.123,.411),(-.15,.375),(-.164,.335),(-.170,.28),(-.167,.025)]
verts=[(x,y,z) for y in [-.085,.085] for x,z in outline];n=len(outline);faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
me=bpy.data.meshes.new('Main soft shell');me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new('Main arched canvas shell',me);bpy.context.collection.objects.link(o);finish(o,o.name,teal)
mod=o.modifiers.new('Rounded stitched edges','BEVEL');mod.width=.013;mod.segments=3;bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.modifier_apply(modifier=mod.name);o.select_set(False);o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
box('Brown reinforced leather bottom',(0,0,.026),(.335,.187,.058),tan,.018)
box('Large front pocket',(0,-.115,.16),(.277,.074,.238),teal,.025)
box('Upper front organizer',(0,-.102,.322),(.28,.045,.087),teal,.017)
# Frontal pocket seams and long black zipper runs.
for name,z,width,y in [('Front pocket zipper',.202,.265,-.154),('Upper organizer zipper',.345,.258,-.128)]:
 box(name,(0,y,z),(width,.004,.006),zipper,.001)
 line(name+' stitched edge',[(-width/2,y-.002,z+.006),(width/2,y-.002,z+.006)],.0006,thread)
 for x in [-width/2+.018+i*.006 for i in range(int((width-.036)/.006))]:box('Zipper teeth',(x,y-.003,z),(.002,.0015,.002),silver,0)
 x=width/2-.019
 box('Metal zipper slider',(x,y-.007,z),(.011,.006,.016),silver,.003)
 line('Hanging metal pull',[(x,y-.012,z-.005),(x+.003,y-.016,z-.026),(x-.003,y-.016,z-.029),(x-.005,y-.012,z-.008)],.0018,silver,True)
 line('Black cord zipper pull',[(x,y-.016,z-.025),(x-.004,y-.022,z-.06),(x-.008,y-.022,z-.072)],.0019,web)
# Main compartment zipper traces the arched shell without opening the bag.
arch=[(-.166,.12),(-.166,.29),(-.16,.342),(-.145,.383),(-.12,.415),(-.078,.44),(0,.45),(.078,.44),(.12,.415),(.145,.383),(.16,.342),(.166,.29),(.166,.12)]
line('Main compartment zipper',[(x,-.025,z) for x,z in arch],.0035,zipper)
for y in [-.081,.082]:line('Canvas edge binding',[(x,y,z) for x,z in outline],.0018,thread,True)
line('Front pocket lower seam',[(-.117,-.153,.058),(-.12,-.154,.10),(-.12,-.154,.17),(.12,-.154,.17),(.12,-.154,.10),(.117,-.153,.058)],.00065,thread)
# Padded back, two independent shoulder straps, adjustment webbing and rectangular buckles.
# The padded back follows the same arched profile as the teal shell, inset at every edge.
back_profile=[(x*.93,.012+(z-.006)*.95) for x,z in outline]
bn=len(back_profile)
bv=[(x,y,z) for y in [.086,.109] for x,z in back_profile]
bf=[tuple(range(bn-1,-1,-1)),tuple(range(bn,2*bn))]+[(i,(i+1)%bn,(i+1)%bn+bn,i+bn) for i in range(bn)]
bm=bpy.data.meshes.new('Arched back cushion profile');bm.from_pydata(bv,[],bf);bm.update()
back=bpy.data.objects.new('Shell-fitted rounded black back cushion',bm);bpy.context.collection.objects.link(back);finish(back,back.name,black)
bevel=back.modifiers.new('Soft cushion perimeter','BEVEL');bevel.width=.009;bevel.segments=4
back.modifiers.new('Soft padded normals','WEIGHTED_NORMAL')
for sign in [-1,1]:
 x=sign*.092
 pts=[(sign*.048,.105,.418),(sign*.067,.133,.382),(x,.153,.31),(sign*.108,.155,.23),(sign*.12,.145,.15),(sign*.128,.124,.085)]
 # Catmull-Rom interpolation removes the blocky bends while retaining editable strips.
 smooth=[]
 extended=[Vector(pts[0])]+[Vector(p) for p in pts]+[Vector(pts[-1])]
 for i in range(1,len(extended)-2):
  a,b,c,d=extended[i-1:i+3]
  for k in range(6):
   t=k/6
   smooth.append(tuple(.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)))
 smooth.append(pts[-1]);pts=smooth
 strap=ribbon('Curved padded shoulder strap',pts,.049,black)
 for face in strap.data.polygons:face.use_smooth=True
 for edge in [-1,1]:line('Strap piping',[(a+edge*.022,b+.003,c) for a,b,c in pts],.0012,web)
 ribbon('Adjustment webbing',[(sign*.128,.124,.092),(sign*.132,.112,.049),(sign*.139,.101,.025)],.022,web)
 buckle=box('Strap adjustment buckle',(sign*.13,.129,.071),(.03,.009,.028),web,.002)
 for zz in [.063,.079]:box('Buckle bar',(sign*.13,.135,zz),(.024,.003,.0025),silver,.0005)
# Carry loop stays above the arched crown.
ribbon('Top carry handle',[(-.031,.017,.432),(-.032,.025,.479),(-.022,.025,.493),(.022,.025,.493),(.032,.025,.479),(.031,.017,.432)],.014,web)
# Two expandable mesh bottle pockets, with a rim and crisscross woven strands.
for sign in [-1,1]:
 x=sign*.174
 side=box('Side pocket dark backing',(x,.008,.133),(.015,.146,.174),meshmat,.009)
 for edge in [-1,1]:line('Side pocket binding',[(x+sign*.008,edge*.064,.06),(x+sign*.012,edge*.067,.211)],.0024,teal)
 line('Elastic pocket top',[(x+sign*.014,-.065,.211),(x+sign*.023,0,.196),(x+sign*.014,.065,.211)],.004,web)
 for slope in [-1,1]:
  for k in range(-10,11):
   points=[]
   for j in range(11):
    z=.058+j*.015;y=k*.014+slope*(z-.13)*.7
    if abs(y)<.065:points.append((x+sign*(.010+.009*math.sin((z-.058)/.153*math.pi)),y,z))
   if len(points)>1:line('Diamond side mesh',points,.00065,meshmat)
# Woven brand patch, matching the reference's dark patch and red/cream lettering.
box('Woven logo patch',(0,-.155,.266),(.086,.002,.039),label,.0015)
line('Label sewn border',[(-.041,-.157,.248),(.041,-.157,.248),(.041,-.157,.284),(-.041,-.157,.284)],.00055,thread,True)
def text(name,body,loc,size,m):
 c=bpy.data.curves.new(name,'FONT');c.body=body;c.align_x='CENTER';c.size=size;c.extrude=.00015;o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(math.pi/2,0,0);o.data.materials.append(m);parts.append(o);return o
text('Cream embroidered logo','JANSPORT',(0,-.158,.259),.014,cream)
text('Red embroidered logo','JANSPORT',(.0008,-.1587,.260),.013,red)
# Convert game geometry, give every part UVs and keep a clean source collection.
bpy.ops.object.select_all(action='DESELECT')
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.convert(target='MESH')
parts=list(bpy.context.selected_objects)
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT')
root=bpy.data.objects.new('Teal backpack - 44cm canvas daypack',None);bpy.context.collection.objects.link(root)
for o in parts:o.parent=root
# Apply weighted normals before exporting, preserve named parts for editing.
for o in parts:
 bpy.context.view_layer.objects.active=o
 for mod in list(o.modifiers):
  try:bpy.ops.object.modifier_apply(modifier=mod.name)
  except:pass
bpy.ops.object.select_all(action='DESELECT')
for o in parts:o.select_set(True)
root.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(out/'teal_backpack.glb'),export_format='GLB',use_selection=True,export_yup=True)
triangles=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in parts)
# Presentation scene: source stays editable and the exported GLB contains only the backpack.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True
scene.world.color=(.20,.20,.20)
floor=mat('Studio backdrop',(.15,.18,.18))
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.007));bpy.context.object.name='Studio floor';bpy.context.object.data.materials.append(floor)
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
for name,loc,power,size in [('Large soft key',(-.7,-.7,1.2),65,1.0),('Soft fill',(.8,-.2,.65),35,.8),('Rear rim',(.2,.6,1.0),80,.7)]:
 bpy.ops.object.light_add(type='AREA',location=loc);l=bpy.context.object;l.name=name;l.data.energy=power;l.data.shape='DISK';l.data.size=size;aim(l,(0,0,.22))
bpy.ops.object.camera_add(location=(.70,-1.1,.65));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=.67;aim(cam,(0,0,.24));scene.camera=cam
scene.render.resolution_x=900;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
scene.view_settings.exposure=-0.65
bpy.ops.wm.save_as_mainfile(filepath=str(out/'teal_backpack.blend'))
scene.render.filepath=str(out/'backpack_front.png');bpy.ops.render.render(write_still=True)
cam.location=(-.68,.95,.60);aim(cam,(0,0,.24));scene.render.filepath=str(out/'backpack_back.png');bpy.ops.render.render(write_still=True)
(out/'model-info.json').write_text(json.dumps({'triangles':triangles,'parts':len(parts),'dimensions_m':[.36,.28,.50],'reference':'Screenshot 2026-10-24 223004.png','export':'teal_backpack.glb'},indent=2))
print('BACKPACK COMPLETE',triangles,'triangles',len(parts),'editable parts')

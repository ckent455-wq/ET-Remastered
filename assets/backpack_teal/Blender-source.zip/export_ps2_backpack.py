import bpy,json
from pathlib import Path
base=Path(r'C:/Users/jkern/Documents/Codex/2026-10-16/go-x20')
bpy.ops.wm.open_mainfile(filepath=str(base/'outputs/models/teal-backpack/teal_backpack.blend'))
root=bpy.data.objects['Teal backpack - 44cm canvas daypack']
bpy.ops.object.select_all(action='DESELECT')
meshes=[o for o in root.children_recursive if o.type=='MESH']
for o in meshes:o.select_set(True)
bpy.context.view_layer.objects.active=meshes[0];bpy.ops.object.join();model=bpy.context.object
model.name='PS2_Teal_Backpack';model.parent=None
mod=model.modifiers.new('Game mesh reduction','DECIMATE');mod.ratio=.34;mod.use_collapse_triangulate=True
bpy.ops.object.modifier_apply(modifier=mod.name)
triangles=sum(len(p.vertices)-2 for p in model.data.polygons)
bpy.ops.export_scene.gltf(filepath=str(base/'outputs/ET-Remastered/assets/backpack_teal/backpack.glb'),export_format='GLB',use_selection=True,export_yup=True)
(base/'outputs/ET-Remastered/assets/backpack_teal/model-info.json').write_text(json.dumps({'triangles':triangles,'source':'teal_backpack.blend','style':'PS2; 256px textures and reduced geometry','reference':'Screenshot 2026-10-24 223004.png'},indent=2))
print('GAME BACKPACK:',triangles,'triangles')
